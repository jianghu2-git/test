# Connecting Parrot to other programs 
----

For advanced use cases, or for when you want to use the noise capabilities of Parrot with the speech recognition capabilities of other programs, it is possible to interact with Parrot.

The following interactions can be executed from outside of Parrot:
- Pausing and resuming the recording
- Stopping Parrot altogether
- Switching modes
- Switching classifiers

As of right now, Parrot needs to run in other to receive these commands
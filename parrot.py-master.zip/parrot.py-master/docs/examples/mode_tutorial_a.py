from config.config import *
from lib.modes.base_mode import *
import time

class TutorialMode(BaseMode):

    def handle_sounds( self, dataDicts ):
        return